<?php

/**
 * 物流信息
 * @author auto create
 */
class DeliveryInfo
{
	
	/** 
	 * 运费信息
	 **/
	public $carriageList;
	
	/** 
	 * 物流目的地
	 **/
	public $destination;
	
	/** 
	 * 所在地
	 **/
	public $location;	
}
?>