<?php

/**
 * 无线描述片段
 * @author auto create
 */
class DescFragment
{
	
	/** 
	 * 内容体目前支持支持图片url
	 **/
	public $content;
	
	/** 
	 * 内容label，目前支持支持图片txt,img
	 **/
	public $label;	
}
?>