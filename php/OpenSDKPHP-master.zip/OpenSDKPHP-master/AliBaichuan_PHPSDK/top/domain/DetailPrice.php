<?php

/**
 * 商品价格和促销价格
 * @author auto create
 */
class DetailPrice
{
	
	/** 
	 * 商品价格
	 **/
	public $price;
	
	/** 
	 * 商品促销价格
	 **/
	public $promotionPrice;	
}
?>