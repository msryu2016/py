<?php

/**
 * 价格信息
 * @author auto create
 */
class DetailPriceInfo
{
	
	/** 
	 * 商品对应的价格
	 **/
	public $itemPrice;
	
	/** 
	 * sku对应的价格列表
	 **/
	public $skuPriceList;	
}
?>