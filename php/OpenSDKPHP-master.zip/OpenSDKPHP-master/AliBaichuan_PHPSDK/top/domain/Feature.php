<?php

/**
 * 类目属性
 * @author auto create
 */
class Feature
{
	
	/** 
	 * 属性键
	 **/
	public $attrKey;
	
	/** 
	 * 属性值
	 **/
	public $attrValue;	
}
?>