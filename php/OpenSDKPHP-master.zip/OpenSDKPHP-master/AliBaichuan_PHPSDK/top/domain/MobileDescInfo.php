<?php

/**
 * 无线描述信息
 * @author auto create
 */
class MobileDescInfo
{
	
	/** 
	 * 无线描述信息
	 **/
	public $descList;	
}
?>