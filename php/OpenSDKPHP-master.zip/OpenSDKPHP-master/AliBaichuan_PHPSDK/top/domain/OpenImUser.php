<?php

/**
 * 用户信息
 * @author auto create
 */
class OpenImUser
{
	
	/** 
	 * 账户appkey
	 **/
	public $appKey;
	
	/** 
	 * 是否为淘宝账号
	 **/
	public $taobaoAccount;
	
	/** 
	 * 用户id
	 **/
	public $uid;	
}
?>