<?php

/**
 * 评价条目
 * @author auto create
 */
class RateItem
{
	
	/** 
	 * 评价内容
	 **/
	public $feedback;
	
	/** 
	 * 评价人nick
	 **/
	public $nick;	
}
?>