<?php

/**
 * 电子凭证线下门店
 * @author auto create
 */
class RetailStore
{
	
	/** 
	 * 地址
	 **/
	public $address;
	
	/** 
	 * 门店名称
	 **/
	public $name;
	
	/** 
	 * 经度
	 **/
	public $posx;
	
	/** 
	 * 纬度
	 **/
	public $posy;
	
	/** 
	 * 门店id
	 **/
	public $storeId;
	
	/** 
	 * 联系电话
	 **/
	public $telnoList;	
}
?>