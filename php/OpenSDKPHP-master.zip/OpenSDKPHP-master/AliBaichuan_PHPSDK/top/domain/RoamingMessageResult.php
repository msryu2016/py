<?php

/**
 * 消息查询结果
 * @author auto create
 */
class RoamingMessageResult
{
	
	/** 
	 * 消息列表
	 **/
	public $messages;
	
	/** 
	 * 下次迭代key
	 **/
	public $nextKey;	
}
?>