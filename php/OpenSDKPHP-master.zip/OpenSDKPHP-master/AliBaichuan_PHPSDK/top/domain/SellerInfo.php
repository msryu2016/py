<?php

/**
 * 卖家信息
 * @author auto create
 */
class SellerInfo
{
	
	/** 
	 * 卖家昵称
	 **/
	public $sellerNick;
	
	/** 
	 * 卖家类型
	 **/
	public $sellerType;
	
	/** 
	 * 卖家店铺名称
	 **/
	public $shopName;	
}
?>