<?php

/**
 * 优惠卷信息
 * @author auto create
 */
class ShopCouponInfo
{
	
	/** 
	 * true|false 是否有优惠卷
	 **/
	public $shopCoupon;	
}
?>