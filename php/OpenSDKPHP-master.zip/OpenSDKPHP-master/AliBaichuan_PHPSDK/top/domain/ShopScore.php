<?php

/**
 * 店铺动态评分信息
 * @author auto create
 */
class ShopScore
{
	
	/** 
	 * 发货速度评分
	 **/
	public $deliveryScore;
	
	/** 
	 * 商品描述评分
	 **/
	public $itemScore;
	
	/** 
	 * 服务态度评分
	 **/
	public $serviceScore;	
}
?>