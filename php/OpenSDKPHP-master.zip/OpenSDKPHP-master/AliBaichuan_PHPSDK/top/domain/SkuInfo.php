<?php

/**
 * SKU信息
 * @author auto create
 */
class SkuInfo
{
	
	/** 
	 * 属性sku映射
	 **/
	public $pvMapSkuList;
	
	/** 
	 * SKU属性列
	 **/
	public $skuProps;	
}
?>