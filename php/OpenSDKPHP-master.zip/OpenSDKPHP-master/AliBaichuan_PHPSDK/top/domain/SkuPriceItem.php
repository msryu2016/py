<?php

/**
 * sku价格
 * @author auto create
 */
class SkuPriceItem
{
	
	/** 
	 * sku一口价
	 **/
	public $price;
	
	/** 
	 * sku促销价
	 **/
	public $promotionPrice;
	
	/** 
	 * skuId
	 **/
	public $skuId;	
}
?>