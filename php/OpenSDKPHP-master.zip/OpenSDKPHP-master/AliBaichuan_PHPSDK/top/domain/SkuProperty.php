<?php

/**
 * SKU属性
 * @author auto create
 */
class SkuProperty
{
	
	/** 
	 * sku属性id
	 **/
	public $propId;
	
	/** 
	 * sku属性名称
	 **/
	public $propName;
	
	/** 
	 * SKU属性值
	 **/
	public $values;	
}
?>