<?php

/**
 * com.taobao.xselect.domain.SkuSelectInfo
 * @author auto create
 */
class SkuSelectInfo
{
	
	/** 
	 * 外部ID
	 **/
	public $outerId;
	
	/** 
	 * sku id
	 **/
	public $skuId;	
}
?>