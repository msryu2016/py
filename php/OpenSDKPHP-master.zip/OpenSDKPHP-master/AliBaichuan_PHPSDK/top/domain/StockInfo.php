<?php

/**
 * 库存信息
 * @author auto create
 */
class StockInfo
{
	
	/** 
	 * 商品库存
	 **/
	public $itemQuantity;
	
	/** 
	 * sku库存列表
	 **/
	public $skuQuantityList;	
}
?>