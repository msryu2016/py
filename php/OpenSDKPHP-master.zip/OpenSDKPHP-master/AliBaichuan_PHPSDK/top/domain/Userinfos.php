<?php

/**
 * 系统自动生成
 * @author auto create
 */
class Userinfos
{
	
	/** 
	 * email地址
	 **/
	public $email;
	
	/** 
	 * 手机号码
	 **/
	public $mobile;
	
	/** 
	 * im密码
	 **/
	public $password;
	
	/** 
	 * 淘宝账号
	 **/
	public $taobaoid;
	
	/** 
	 * im用户名
	 **/
	public $userid;	
}
?>